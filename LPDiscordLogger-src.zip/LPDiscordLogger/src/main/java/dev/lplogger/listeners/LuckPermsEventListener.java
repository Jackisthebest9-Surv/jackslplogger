package dev.lplogger.listeners;

import dev.lplogger.LPDiscordLogger;
import dev.lplogger.editor.EditorChangeTracker;
import dev.lplogger.webhook.DiscordWebhook;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeClearEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.model.PermissionHolder;
import net.luckperms.api.node.Node;

public class LuckPermsEventListener {

    private final LPDiscordLogger plugin;
    private final DiscordWebhook webhook;
    private final EditorChangeTracker editorTracker;

    public LuckPermsEventListener(LPDiscordLogger plugin, DiscordWebhook webhook, EditorChangeTracker editorTracker) {
        this.plugin = plugin;
        this.webhook = webhook;
        this.editorTracker = editorTracker;
    }

    /**
     * Called when any node is added to a holder (user or group).
     */
    public void onNodeAdd(NodeAddEvent event) {
        PermissionHolder holder = event.getTarget();
        Node node = event.getNode();

        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);
        String nodeKey = formatNode(node);

        // Route to editor tracker if there's an active editor session for this holder
        if (editorTracker.isTracking()) {
            editorTracker.recordAddition(holderName, holderType, nodeKey);
        }
    }

    /**
     * Called when any node is removed from a holder.
     */
    public void onNodeRemove(NodeRemoveEvent event) {
        PermissionHolder holder = event.getTarget();
        Node node = event.getNode();

        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);
        String nodeKey = formatNode(node);

        if (editorTracker.isTracking()) {
            editorTracker.recordRemoval(holderName, holderType, nodeKey);
        }
    }

    /**
     * Called when all nodes are cleared from a holder.
     */
    public void onNodeClear(NodeClearEvent event) {
        PermissionHolder holder = event.getTarget();
        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);

        if (editorTracker.isTracking()) {
            // Record the clear as a bulk event
            editorTracker.recordClear(holderName, holderType, event.getNodes().size());
        }
    }

    private String getHolderName(PermissionHolder holder) {
        return holder.getFriendlyName();
    }

    private String getHolderType(PermissionHolder holder) {
        return holder.getType().name().toLowerCase();
    }

    /**
     * Formats a node into a readable string, including context and value.
     */
    private String formatNode(Node node) {
        StringBuilder sb = new StringBuilder();

        // Negated?
        if (!node.getValue()) sb.append("-");

        sb.append(node.getKey());

        // Expiry
        if (node.hasExpiry()) {
            long seconds = node.getExpiry().getEpochSecond() - (System.currentTimeMillis() / 1000);
            sb.append(" (expires in ").append(formatDuration(seconds)).append(")");
        }

        // Context
        if (!node.getContexts().isEmpty()) {
            node.getContexts().forEach((key, value) ->
                    sb.append(" [").append(key).append("=").append(value).append("]"));
        }

        return sb.toString();
    }

    private String formatDuration(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m";
        if (seconds < 86400) return (seconds / 3600) + "h";
        return (seconds / 86400) + "d";
    }
}
