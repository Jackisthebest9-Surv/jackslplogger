package dev.lplogger.commands;

import dev.lplogger.LPDiscordLogger;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {

    private final LPDiscordLogger plugin;

    public ReloadCommand(LPDiscordLogger plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || !args[0].equalsIgnoreCase("reload")) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /lpdl reload");
            return true;
        }

        boolean success = plugin.reloadPluginConfig();

        if (success) {
            sender.sendMessage(ChatColor.GREEN + "LPDiscordLogger config reloaded.");
            plugin.getLogger().info("Config reloaded via /lpdl reload by " + sender.getName() + ".");
        } else {
            sender.sendMessage(ChatColor.RED
                    + "Reloaded, but webhook-url is missing or empty in config.yml! Logging will not work.");
        }

        return true;
    }
}
