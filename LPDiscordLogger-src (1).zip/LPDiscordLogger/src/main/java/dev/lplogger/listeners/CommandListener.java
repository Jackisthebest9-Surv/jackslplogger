package dev.lplogger.listeners;

import dev.lplogger.LPDiscordLogger;
import dev.lplogger.editor.EditorChangeTracker;
import dev.lplogger.webhook.DiscordWebhook;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class CommandListener implements Listener {

    private final LPDiscordLogger plugin;
    private final DiscordWebhook webhook;
    private final EditorChangeTracker editorTracker;

    private static final Set<String> EDITOR_SUBCOMMANDS = new HashSet<>(Arrays.asList(
            "editor", "edit"
    ));

    /** Must match the list in LuckPermsEventListener exactly. */
    private static final Set<String> SUPPRESSED_GROUPS = Set.of(
            "worldcup", "carnage", "custom", "trainee", "dominator",
            "influencer", "streamer", "teamtop", "werule", "king",
            "crusader", "champion", "knight", "footman"
    );

    /** 8 days in seconds. */
    private static final long THRESHOLD_SECONDS = 8L * 24 * 60 * 60;

    public CommandListener(LPDiscordLogger plugin, DiscordWebhook webhook, EditorChangeTracker editorTracker) {
        this.plugin = plugin;
        this.webhook = webhook;
        this.editorTracker = editorTracker;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfig().getBoolean("log-players", true)) return;

        String message = event.getMessage().toLowerCase().trim();
        if (!isLuckPermsCommand(message)) return;

        String fullCommand = event.getMessage().trim();

        if (isSuppressedTempRankCommand(fullCommand)) return;

        Player player = event.getPlayer();
        String senderName = player.getName();

        if (isEditorCommand(fullCommand)) {
            editorTracker.registerEditorSession(player.getUniqueId(), senderName, fullCommand);
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                webhook.sendCommandLog(senderName, false, fullCommand, resolveCommandOutcome(fullCommand)), 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsoleCommand(ServerCommandEvent event) {
        if (!plugin.getConfig().getBoolean("log-console", true)) return;

        String command = event.getCommand().toLowerCase().trim();
        if (!isLuckPermsCommand("/" + command) && !isLuckPermsCommand(command)) return;

        String fullCommand = event.getCommand().trim();

        if (isSuppressedTempRankCommand(fullCommand)) return;

        if (isEditorCommand(fullCommand)) {
            editorTracker.registerEditorSession(null, "Console", fullCommand);
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                webhook.sendCommandLog("Console", true, fullCommand, resolveCommandOutcome(fullCommand)), 1L);
    }

    /**
     * Returns true if this command is a temp-rank grant/removal for a suppressed
     * group with a duration under the 8-day threshold.
     *
     * Matches commands of the form:
     *   /lp user <name> parent addtemp <group> <duration>
     *   /lp user <name> parent settemp <group> <duration>
     *   /lp user <name> parent removetemp <group>    <- always suppress removals of suppressed groups
     */
    private boolean isSuppressedTempRankCommand(String fullCommand) {
        // Strip the /lp or /luckperms prefix and split into tokens
        String args = fullCommand.replaceFirst("(?i)^/?luck(perms)?\\s*", "").trim();
        String[] parts = args.split("\\s+");

        // Minimum: user <name> parent addtemp/settemp/removetemp <group>
        // parts:     0     1      2       3                          4
        if (parts.length < 5) return false;

        String sub = parts[0].toLowerCase();
        if (!sub.equals("user")) return false;

        String action = parts[2].toLowerCase();
        if (!action.equals("parent")) return false;

        String tempAction = parts[3].toLowerCase();
        boolean isAdd = tempAction.equals("addtemp") || tempAction.equals("settemp");
        boolean isRemove = tempAction.equals("removetemp");
        if (!isAdd && !isRemove) return false;

        String groupName = parts[4].toLowerCase(Locale.ROOT);
        if (!SUPPRESSED_GROUPS.contains(groupName)) return false;

        // Removals of a suppressed group are always suppressed
        if (isRemove) return true;

        // For adds: suppress only if duration < 8 days
        // Duration is parts[5] if present, e.g. "7d", "12h", "1d12h"
        if (parts.length < 6) return false;
        long durationSeconds = parseDuration(parts[5]);
        return durationSeconds > 0 && durationSeconds < THRESHOLD_SECONDS;
    }

    /**
     * Parses a LuckPerms duration string into total seconds.
     * Supports combinations like "1d", "12h", "30m", "1d12h30m", "7d12h".
     * Returns 0 if unparseable.
     */
    private long parseDuration(String input) {
        long total = 0;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(\\d+)([smhdwy])")
                .matcher(input.toLowerCase(Locale.ROOT));
        boolean found = false;
        while (m.find()) {
            found = true;
            long value = Long.parseLong(m.group(1));
            total += switch (m.group(2)) {
                case "s" -> value;
                case "m" -> value * 60;
                case "h" -> value * 3600;
                case "d" -> value * 86400;
                case "w" -> value * 604800;
                case "y" -> value * 31536000L;
                default  -> 0;
            };
        }
        return found ? total : 0;
    }

    private boolean isLuckPermsCommand(String msg) {
        String lower = msg.toLowerCase();
        return lower.startsWith("/lp ") || lower.equals("/lp")
                || lower.startsWith("/luckperms ") || lower.equals("/luckperms")
                || lower.startsWith("lp ") || lower.equals("lp")
                || lower.startsWith("luckperms ") || lower.equals("luckperms");
    }

    private boolean isEditorCommand(String fullCommand) {
        String[] parts = fullCommand.replaceFirst("(?i)^/?luck(perms)?\\s*", "").trim().split("\\s+");
        if (parts.length == 0) return false;
        return EDITOR_SUBCOMMANDS.contains(parts[0].toLowerCase());
    }

    private String resolveCommandOutcome(String fullCommand) {
        String args = fullCommand.replaceFirst("(?i)^/?luck(perms)?\\s*", "").trim();
        if (args.isEmpty()) return "Opened LuckPerms help.";

        String[] parts = args.split("\\s+");
        String sub = parts[0].toLowerCase();

        return switch (sub) {
            case "editor", "edit" -> "Opened the LuckPerms web editor.";
            case "user"   -> parts.length > 2 ? "User command on **" + parts[1] + "**: `" + parts[2] + "`" : "User command issued.";
            case "group"  -> parts.length > 2 ? "Group command on **" + parts[1] + "**: `" + parts[2] + "`" : "Group command issued.";
            case "track"  -> parts.length > 2 ? "Track command on **" + parts[1] + "**: `" + parts[2] + "`" : "Track command issued.";
            case "sync"        -> "Synchronised LuckPerms data.";
            case "info"        -> "Displayed LuckPerms info.";
            case "verbose"     -> "Toggled verbose mode.";
            case "tree"        -> "Displayed permission tree.";
            case "search"      -> parts.length > 1 ? "Searched for permission: `" + parts[1] + "`" : "Searched permissions.";
            case "check"       -> "Checked a permission.";
            case "networksync" -> "Triggered network sync.";
            case "reload"      -> "Reloaded LuckPerms configuration.";
            case "export"      -> "Exported LuckPerms data.";
            case "import"      -> "Imported LuckPerms data.";
            case "bulkupdate"  -> "Bulk update command issued.";
            case "apply-edits" -> "Applied editor session changes.";
            default -> "Command `" + sub + "` executed.";
        };
    }
}
