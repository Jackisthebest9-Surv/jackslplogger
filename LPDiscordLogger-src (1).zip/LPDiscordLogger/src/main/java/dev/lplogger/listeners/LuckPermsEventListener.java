package dev.lplogger.listeners;

import dev.lplogger.LPDiscordLogger;
import dev.lplogger.editor.EditorChangeTracker;
import dev.lplogger.webhook.DiscordWebhook;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeClearEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.model.PermissionHolder;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;

import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class LuckPermsEventListener {

    private final LPDiscordLogger plugin;
    private final DiscordWebhook webhook;
    private final EditorChangeTracker editorTracker;

    /** 8 days in seconds — grants shorter than this are suppressed for watched groups. */
    private static final long THRESHOLD_SECONDS = 8L * 24 * 60 * 60;

    /**
     * Group names (lowercase) whose short-duration temp grants/losses are suppressed.
     * Permanent grants of these groups are always logged.
     */
    private static final Set<String> SUPPRESSED_GROUPS = Set.of(
            "worldcup", "carnage", "custom", "trainee", "dominator",
            "influencer", "streamer", "teamtop", "werule", "king",
            "crusader", "champion", "knight", "footman"
    );

    /**
     * Remembers "holder:group" pairs that were suppressed at grant time so the
     * matching removal event is also suppressed. Entries are added on a suppressed
     * NodeAddEvent and removed when the corresponding NodeRemoveEvent fires.
     * ConcurrentHashMap used as a Set for thread safety.
     */
    private final Set<String> suppressedPairs = ConcurrentHashMap.newKeySet();

    public LuckPermsEventListener(LPDiscordLogger plugin, DiscordWebhook webhook, EditorChangeTracker editorTracker) {
        this.plugin = plugin;
        this.webhook = webhook;
        this.editorTracker = editorTracker;
    }

    public void onNodeAdd(NodeAddEvent event) {
        PermissionHolder holder = event.getTarget();
        Node node = event.getNode();

        if (shouldSuppress(holder, node, true)) return;

        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);
        String nodeKey = formatNode(node);

        editorTracker.recordAddition(holderName, holderType, nodeKey);
    }

    public void onNodeRemove(NodeRemoveEvent event) {
        PermissionHolder holder = event.getTarget();
        Node node = event.getNode();

        if (shouldSuppress(holder, node, false)) return;

        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);
        String nodeKey = formatNode(node);

        editorTracker.recordRemoval(holderName, holderType, nodeKey);
    }

    public void onNodeClear(NodeClearEvent event) {
        PermissionHolder holder = event.getTarget();
        String holderName = getHolderName(holder);
        String holderType = getHolderType(holder);

        editorTracker.recordClear(holderName, holderType, event.getNodes().size());
    }

    // -----------------------------------------------------------------------
    // Suppression logic
    // -----------------------------------------------------------------------

    /**
     * Returns true if this node event should be silently discarded.
     *
     * @param isAddEvent true for NodeAddEvent, false for NodeRemoveEvent
     */
    private boolean shouldSuppress(PermissionHolder holder, Node node, boolean isAddEvent) {
        String groupName = extractGroupName(node.getKey());
        if (groupName == null || !SUPPRESSED_GROUPS.contains(groupName)) return false;

        String pairKey = getHolderName(holder) + ":" + groupName;

        if (isAddEvent) {
            // Permanent grants of suppressed groups are always logged.
            if (!node.hasExpiry()) return false;

            // Calculate the original grant duration (time from now to expiry).
            long durationSeconds = node.getExpiry().getEpochSecond()
                    - (System.currentTimeMillis() / 1000L);

            if (durationSeconds < THRESHOLD_SECONDS) {
                // Suppress this add, and remember it so the remove is also suppressed.
                suppressedPairs.add(pairKey);
                plugin.getLogger().info("[LPLogger] Suppressed short temp-rank grant: "
                        + pairKey + " (" + formatDuration(durationSeconds) + ")");
                return true;
            }
            return false;

        } else {
            // Remove event — suppress all removals of watched temp groups.
            // We suppress regardless of hasExpiry() because very short-lived nodes
            // (e.g. 10s) may already be past their expiry by the time this event fires,
            // causing hasExpiry() to return false even though it was a temp grant.
            // The only case we want to log is a permanent grant being manually removed
            // by staff — but since we can't distinguish that reliably at removal time,
            // we suppress all removals of watched groups unconditionally.
            suppressedPairs.remove(pairKey);
            plugin.getLogger().info("[LPLogger] Suppressed temp-rank removal: " + pairKey);
            return true;
        }
    }

    /**
     * Extracts the group name from a LuckPerms group node key.
     * e.g. "group.knight" -> "knight", "some.permission" -> null
     */
    private String extractGroupName(String nodeKey) {
        if (nodeKey == null) return null;
        String lower = nodeKey.toLowerCase(Locale.ROOT);
        if (!lower.startsWith("group.")) return null;
        return lower.substring(6); // strip "group."
    }

    // -----------------------------------------------------------------------

    private String getHolderName(PermissionHolder holder) {
        return holder.getFriendlyName();
    }

    private String getHolderType(PermissionHolder holder) {
        if (holder instanceof User) return "user";
        if (holder instanceof Group) return "group";
        return "unknown";
    }

    private String formatNode(Node node) {
        StringBuilder sb = new StringBuilder();

        sb.append(node.getKey());
        sb.append(" (").append(node.getValue() ? "true" : "false").append(")");

        if (node.hasExpiry()) {
            long seconds = node.getExpiry().getEpochSecond() - (System.currentTimeMillis() / 1000);
            sb.append(" (expires in ").append(formatDuration(seconds)).append(")");
        }

        node.getContexts().toSet().forEach(ctx ->
                sb.append(" [").append(ctx.getKey()).append("=").append(ctx.getValue()).append("]"));

        return sb.toString();
    }

    private String formatDuration(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m";
        if (seconds < 86400) return (seconds / 3600) + "h";
        return (seconds / 86400) + "d";
    }
}
