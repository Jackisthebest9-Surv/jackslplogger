package dev.lplogger.editor;

import dev.lplogger.LPDiscordLogger;
import dev.lplogger.webhook.DiscordWebhook;
import net.luckperms.api.LuckPerms;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks LuckPerms node changes and batches them into a single Discord embed.
 *
 * Strategy: always listen for node events. When a burst of changes arrives
 * (which is what happens when the editor applies), debounce them and fire one embed.
 * A "burst" is defined as multiple changes arriving within FLUSH_DELAY_TICKS of each other.
 *
 * Single node changes from direct commands are also captured this way, but those
 * are already logged by the command listener — so we only fire the editor embed
 * when 2+ changes arrive in the same burst (editor always sends multiple at once).
 */
public class EditorChangeTracker {

    private final LPDiscordLogger plugin;
    private final DiscordWebhook webhook;

    // Who opened the editor most recently
    private volatile String lastEditorInitiator = "Unknown";
    private volatile long lastEditorOpenTime = 0;

    // Accumulated changes keyed by "type:name"
    private final Map<String, HolderChanges> changeMap = new ConcurrentHashMap<>();

    // Debounce task
    private BukkitTask flushTask = null;

    // Wait 2 seconds after the last node event before flushing
    private static final long FLUSH_DELAY_TICKS = 40L;

    // Only fire an editor embed if changes arrive within 15 minutes of /lp editor
    private static final long EDITOR_WINDOW_MS = 15 * 60 * 1000L;

    public EditorChangeTracker(LPDiscordLogger plugin, LuckPerms luckPerms, DiscordWebhook webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
    }

    /**
     * Called when /lp editor (or similar) is run.
     */
    public void registerEditorSession(UUID initiatorUUID, String initiatorName, String fullCommand) {
        lastEditorInitiator = initiatorName;
        lastEditorOpenTime = System.currentTimeMillis();
        plugin.getLogger().info("[LPLogger] Editor session registered by " + initiatorName);
    }

    /**
     * Records a permission addition.
     */
    public void recordAddition(String holderName, String holderType, String nodeKey) {
        getOrCreate(holderName, holderType).added.add(nodeKey);
        scheduleFlush();
    }

    /**
     * Records a permission removal.
     */
    public void recordRemoval(String holderName, String holderType, String nodeKey) {
        getOrCreate(holderName, holderType).removed.add(nodeKey);
        scheduleFlush();
    }

    /**
     * Records a full clear.
     */
    public void recordClear(String holderName, String holderType, int nodeCount) {
        getOrCreate(holderName, holderType).removed.add(
                "*All permissions cleared (" + nodeCount + " nodes removed)*");
        scheduleFlush();
    }

    /**
     * Always returns true — we track all node events and decide at flush time
     * whether to send the embed.
     */
    public boolean isTracking() {
        return true;
    }

    // -----------------------------------------------------------------------

    private HolderChanges getOrCreate(String holderName, String holderType) {
        String key = holderType + ":" + holderName;
        return changeMap.computeIfAbsent(key, k -> new HolderChanges(holderName, holderType));
    }

    private void scheduleFlush() {
        if (flushTask != null) {
            flushTask.cancel();
        }
        flushTask = plugin.getServer().getScheduler()
                .runTaskLater(plugin, this::flush, FLUSH_DELAY_TICKS);
    }

    private void flush() {
        if (changeMap.isEmpty()) return;

        int totalChanges = changeMap.values().stream()
                .mapToInt(c -> c.added.size() + c.removed.size())
                .sum();

        // Determine initiator label
        boolean withinEditorWindow = (System.currentTimeMillis() - lastEditorOpenTime) < EDITOR_WINDOW_MS;
        String initiator = withinEditorWindow ? lastEditorInitiator : "Direct Command / API";

        plugin.getLogger().info("[LPLogger] Flushing " + totalChanges
                + " node change(s) across " + changeMap.size()
                + " holder(s). Initiator: " + initiator);

        for (HolderChanges changes : changeMap.values()) {
            if (changes.added.isEmpty() && changes.removed.isEmpty()) continue;

            webhook.sendEditorLog(
                    initiator,
                    changes.holderName,
                    changes.holderType,
                    new ArrayList<>(changes.added),
                    new ArrayList<>(changes.removed),
                    changes.added.size() + changes.removed.size()
            );
        }

        changeMap.clear();
        flushTask = null;
    }

    // -----------------------------------------------------------------------

    private static class HolderChanges {
        final String holderName;
        final String holderType;
        final LinkedHashSet<String> added = new LinkedHashSet<>();
        final LinkedHashSet<String> removed = new LinkedHashSet<>();

        HolderChanges(String holderName, String holderType) {
            this.holderName = holderName;
            this.holderType = holderType;
        }
    }
}
