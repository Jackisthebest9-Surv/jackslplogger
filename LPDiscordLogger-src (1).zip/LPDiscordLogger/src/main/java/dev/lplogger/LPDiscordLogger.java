package dev.lplogger;

import dev.lplogger.editor.EditorChangeTracker;
import dev.lplogger.listeners.CommandListener;
import dev.lplogger.listeners.LuckPermsEventListener;
import dev.lplogger.webhook.DiscordWebhook;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeClearEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class LPDiscordLogger extends JavaPlugin {

    private static LPDiscordLogger instance;
    private LuckPerms luckPerms;
    private DiscordWebhook discordWebhook;
    private EditorChangeTracker editorChangeTracker;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Hook into LuckPerms
        RegisteredServiceProvider<LuckPerms> provider = Bukkit.getServicesManager()
                .getRegistration(LuckPerms.class);

        if (provider == null) {
            getLogger().severe("LuckPerms not found! Disabling LPDiscordLogger.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        luckPerms = provider.getProvider();
        getLogger().info("Hooked into LuckPerms.");

        // Webhook
        String webhookUrl = getConfig().getString("webhook-url", "");
        if (webhookUrl.isEmpty()) {
            getLogger().severe("No webhook URL configured! Disabling.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        discordWebhook = new DiscordWebhook(this, webhookUrl);

        // Editor tracker
        editorChangeTracker = new EditorChangeTracker(this, luckPerms, discordWebhook);

        // Bukkit command listener
        CommandListener commandListener = new CommandListener(this, discordWebhook, editorChangeTracker);
        Bukkit.getPluginManager().registerEvents(commandListener, this);

        // LuckPerms node event listeners — must use EventBus
        LuckPermsEventListener lpListener = new LuckPermsEventListener(this, discordWebhook, editorChangeTracker);

        luckPerms.getEventBus().subscribe(this, NodeAddEvent.class, lpListener::onNodeAdd);
        luckPerms.getEventBus().subscribe(this, NodeRemoveEvent.class, lpListener::onNodeRemove);
        luckPerms.getEventBus().subscribe(this, NodeClearEvent.class, lpListener::onNodeClear);

        getLogger().info("LPDiscordLogger enabled. Listening for LuckPerms node events.");
    }

    @Override
    public void onDisable() {
        getLogger().info("LPDiscordLogger disabled.");
    }

    public static LPDiscordLogger getInstance() {
        return instance;
    }

    public LuckPerms getLuckPerms() {
        return luckPerms;
    }

    public DiscordWebhook getDiscordWebhook() {
        return discordWebhook;
    }

    public EditorChangeTracker getEditorChangeTracker() {
        return editorChangeTracker;
    }
}
